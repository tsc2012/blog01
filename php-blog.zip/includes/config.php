<?php
/**
 * 全局配置文件
 * 包含数据库配置、路径设置和站点信息
 */

// 数据库配置
define('DB_HOST', 'localhost');     // 数据库主机
define('DB_USER', 'root');          // 数据库用户名
define('DB_PASS', '');              // 数据库密码
define('DB_NAME', 'php_blog');      // 数据库名称
define('DB_CHARSET', 'utf8mb4');    // 数据库字符集

// 路径配置
define('BASE_URL', 'http://localhost/php-blog'); // 网站根URL
define('ROOT_DIR', dirname(__DIR__));            // 网站根目录

// 站点信息
define('SITE_NAME', 'PHP博客系统');              // 网站名称
define('SITE_DESCRIPTION', '一个简单而强大的PHP博客系统'); // 网站描述
define('SITE_AUTHOR', 'PHP博客作者');            // 网站作者

// 上传配置
define('UPLOAD_DIR', ROOT_DIR . '/uploads/');    // 上传目录
define('UPLOAD_URL', BASE_URL . '/uploads/');    // 上传URL
define('MAX_UPLOAD_SIZE', 5242880);              // 最大上传大小(5MB)
define('ALLOWED_FILE_TYPES', ['image/jpeg', 'image/png', 'image/gif']); // 允许的文件类型

// 分页配置
define('POSTS_PER_PAGE', 10);       // 每页显示文章数
define('COMMENTS_PER_PAGE', 20);    // 每页显示评论数

// 安全配置
define('COOKIE_SECURE', false);     // 仅HTTPS传输Cookie
define('COOKIE_HTTPONLY', true);    // 防止XSS攻击获取Cookie
define('COOKIE_SAMESITE', 'Lax');   // 限制第三方Cookie

// 错误报告配置
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', ROOT_DIR . '/logs/error.log');

// 确保日志目录存在
if (!file_exists(ROOT_DIR . '/logs')) {
    mkdir(ROOT_DIR . '/logs', 0755, true);
}

// 确保上传目录存在并设置正确权限
if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}
