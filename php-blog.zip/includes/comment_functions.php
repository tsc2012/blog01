<?php
/**
 * 评论相关函数
 * 包含评论的添加、获取等功能
 */

require_once 'db.php';

/**
 * 获取文章的评论
 * @param int $post_id 文章ID
 * @param int $limit 限制数量
 * @param int $offset 偏移量
 * @return array 评论列表
 */
function get_comments_by_post($post_id, $limit = COMMENTS_PER_PAGE, $offset = 0) {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM comments WHERE post_id = :post_id AND status = 'approved' ORDER BY created_at ASC LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * 获取所有评论（管理端用）
 * @param string $status 评论状态：all, pending, approved, spam
 * @param int $limit 限制数量
 * @param int $offset 偏移量
 * @return array 评论列表
 */
function get_all_comments($status = 'all', $limit = 20, $offset = 0) {
    $db = get_db_connection();
    
    if ($status == 'all') {
        $stmt = $db->prepare("SELECT c.*, p.title as post_title FROM comments c LEFT JOIN posts p ON c.post_id = p.id ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
    } else {
        $stmt = $db->prepare("SELECT c.*, p.title as post_title from comments c LEFT JOIN posts p ON c.post_id = p.id WHERE c.status = :status ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    }
    
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * 获取评论总数
 * @param int|null $post_id 可选文章ID
 * @param string $status 评论状态
 * @return int 评论总数
 */
function get_total_comments($post_id = null, $status = 'approved') {
    $db = get_db_connection();
    $params = [];
    $conditions = [];
    
    if ($post_id) {
        $conditions[] = "post_id = :post_id";
        $params[':post_id'] = $post_id;
    }
    
    if ($status != 'all') {
        $conditions[] = "status = :status";
        $params[':status'] = $status;
    }
    
    $sql = "SELECT COUNT(*) as total FROM comments";
    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $result = $stmt->fetch();
    return $result['total'];
}

/**
 * 添加评论
 * @param array $data 评论数据
 * @return int|false 评论ID或false
 */
function add_comment($data) {
    $db = get_db_connection();
    
    // 验证数据
    if (empty($data['post_id']) || empty($data['name']) || empty($data['email']) || empty($data['content'])) {
        return false;
    }
    
    // 检查文章是否存在
    $stmt = $db->prepare("SELECT id FROM posts WHERE id = :post_id");
    $stmt->bindParam(':post_id', $data['post_id'], PDO::PARAM_INT);
    $stmt->execute();
    
    if (!$stmt->fetch()) {
        return false;
    }
    
    // 准备数据
    $post_id = intval($data['post_id']);
    $name = clean_input($data['name']);
    $email = filter_var($data['email'], FILTER_VALIDATE_EMAIL) ? $data['email'] : '';
    $website = !empty($data['website']) ? filter_var($data['website'], FILTER_VALIDATE_URL) : '';
    $content = clean_input($data['content']);
    $status = 'pending'; // 默认待审核
    $created_at = date('Y-m-d H:i:s');
    
    // 检查邮箱格式
    if (!$email) {
        return false;
    }
    
    // 插入评论
    $stmt = $db->prepare("INSERT INTO comments (post_id, name, email, website, content, status, created_at) 
                        VALUES (:post_id, :name, :email, :website, :content, :status, :created_at)");
    
    $stmt->bindParam(':post_id', $post_id, PDO::PARAM_INT);
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':website', $website, PDO::PARAM_STR);
    $stmt->bindParam(':content', $content, PDO::PARAM_STR);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':created_at', $created_at, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        return $db->lastInsertId();
    }
    
    return false;
}

/**
 * 更新评论状态
 * @param int $id 评论ID
 * @param string $status 状态：pending, approved, spam
 * @return bool 是否成功
 */
function update_comment_status($id, $status) {
    $db = get_db_connection();
    
    // 验证状态
    $valid_statuses = ['pending', 'approved', 'spam'];
    if (!in_array($status, $valid_statuses)) {
        return false;
    }
    
    $stmt = $db->prepare("UPDATE comments SET status = :status WHERE id = :id");
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    
    return $stmt->execute();
}

/**
 * 删除评论
 * @param int $id 评论ID
 * @return bool 是否成功
 */
function delete_comment($id) {
    $db = get_db_connection();
    $stmt = $db->prepare("DELETE FROM comments WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    return $stmt->execute();
}

/**
 * 获取单个评论
 * @param int $id 评论ID
 * @return array|null 评论数据或null
 */
function get_comment_by_id($id) {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM comments WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}
