<?php
/**
 * 全局通用通用函数
 * 包含网站全局使用的辅助函数
 */

require_once 'db.php';

/**
 * 获取所有文章
 * @param int $limit 限制数量
 * @param int $offset 偏移量
 * @return array 文章列表
 */
function get_all_posts($limit = POSTS_PER_PAGE, $offset = 0) {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT p.*, c.name as category_name 
                        FROM posts p 
                        LEFT JOIN categories c ON p.category_id = c.id 
                        ORDER BY p.created_at DESC 
                        LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * 获取单篇文章
 * @param int $id 文章ID
 * @return array|null 文章数据或null
 */
function get_post_by_id($id) {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT p.*, c.name as category_name 
                        FROM posts p 
                        LEFT JOIN categories c ON p.category_id = c.id 
                        WHERE p.id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}

/**
 * 获取分类下的文章
 * @param int $category_id 分类ID
 * @param int $limit 限制数量
 * @param int $offset 偏移量
 * @return array 文章列表
 */
function get_posts_by_category($category_id, $limit = POSTS_PER_PAGE, $offset = 0) {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT p.*, c.name as category_name 
                        FROM posts p 
                        LEFT JOIN categories c ON p.category_id = c.id 
                        WHERE p.category_id = :category_id 
                        ORDER BY p.created_at DESC 
                        LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * 获取所有分类
 * @return array 分类列表
 */
function get_all_categories() {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM categories ORDER BY name ASC");
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * 获取单个分类
 * @param int $id 分类ID
 * @return array|null 分类数据或null
 */
function get_category_by_id($id) {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM categories WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}

/**
 * 获取文章总数
 * @param int|null $category_id 可选分类ID
 * @return int 文章总数
 */
function get_total_posts($category_id = null) {
    $db = get_db_connection();
    
    if ($category_id) {
        $stmt = $db->prepare("SELECT COUNT(*) as total FROM posts WHERE category_id = :category_id");
        $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    } else {
        $stmt = $db->prepare("SELECT COUNT(*) as total FROM posts");
    }
    
    $stmt->execute();
    $result = $stmt->fetch();
    return $result['total'];
}

/**
 * 获取分页链接
 * @param int $total 总记录数
 * @param int $per_page 每页记录数
 * @param int $current_page 当前页码
 * @param string $base_url 基础URL
 * @return string 分页HTML
 */
function get_pagination_links($total, $per_page, $current_page, $base_url) {
    $total_pages = ceil($total / $per_page);
    $pagination = '';
    
    if ($total_pages > 1) {
        $pagination .= '<div class="pagination">';
        
        // 上一页
        if ($current_page > 1) {
            $pagination .= '<a href="' . $base_url . '?page=' . ($current_page - 1) . '">&laquo; 上一页</a>';
        }
        
        // 页码
        for ($i = 1; $i <= $total_pages; $i++) {
            if ($i == $current_page) {
                $pagination .= '<span class="current">' . $i . '</span>';
            } else {
                $pagination .= '<a href="' . $base_url . '?page=' . $i . '">' . $i . '</a>';
            }
        }
        
        // 下一页
        if ($current_page < $total_pages) {
            $pagination .= '<a href="' . $base_url . '?page=' . ($current_page + 1) . '">下一页 &raquo;</a>';
        }
        
        $pagination .= '</div>';
    }
    
    return $pagination;
}

/**
 * 处理用户输入
 * @param string $input 输入内容
 * @return string 处理后的内容
 */
function clean_input($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}

/**
 * 上传文件
 * @param array $file 文件信息
 * @param string $upload_dir 上传目录
 * @return string|false 文件名或false
 */
function upload_file($file, $upload_dir = UPLOAD_DIR) {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    // 检查文件类型
    if (!in_array($file['type'], ALLOWED_FILE_TYPES)) {
        return false;
    }
    
    // 检查文件大小
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return false;
    }
    
    // 生成唯一文件名
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '.' . $extension;
    $destination = $upload_dir . $filename;
    
    // 移动上传文件
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        // 设置文件权限
        chmod($destination, 0644);
        return $filename;
    }
    
    return false;
}

/**
 * 显示消息提示
 * @param string $message 消息内容
 * @param string $type 消息类型：success, error, warning, info
 */
function show_message($message, $type = 'info') {
    $types = ['success', 'error', 'warning', 'info'];
    $type = in_array($type, $types) ? $type : 'info';
    
    echo '<div class="alert alert-' . $type . '">';
    echo '<p>' . $message . '</p>';
    echo '</div>';
}

/**
 * 重定向到指定URL
 * @param string $url 目标URL
 */
function redirect($url) {
    header('Location: ' . $url);
    exit();
}

/**
 * 获取当前页码
 * @return int 当前页码
 */
function get_current_page() {
    return isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
}

/**
 * 生成随机字符串
 * @param int $length 字符串长度
 * @return string 随机字符串
 */
function generate_random_string($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $random_string = '';
    
    for ($i = 0; $i < $length; $i++) {
        $random_string .= $characters[rand(0, strlen($characters) - 1)];
    }
    
    return $random_string;
}

/**
 * 格式化日期时间
 * @param string $datetime 日期时间字符串
 * @param string $format 格式
 * @return string 格式化后的日期时间
 */
function format_datetime($datetime, $format = 'Y-m-d H:i:s') {
    return date($format, strtotime($datetime));
}
