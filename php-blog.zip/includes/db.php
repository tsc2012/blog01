<?php
/**
 * 数据库连接文件
 * 提供全局数据库连接
 */

require_once 'config.php';

// 数据库连接类
class Database {
    private static $instance = null;
    private $conn;
    
    // 私有构造函数，防止外部实例化
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            
            $this->conn = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("数据库连接失败: " . $e->getMessage());
            die("数据库连接失败，请稍后重试。");
        }
    }
    
    // 获取数据库连接实例（单例模式）
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
    
    // 获取PDO连接对象
    public function getConnection() {
        return $this->conn;
    }
    
    // 防止克隆
    private function __clone() {}
    
    // 防止反序列化
    private function __wakeup() {}
}

// 获取数据库连接
function get_db_connection() {
    return Database::getInstance()->getConnection();
}

// 测试数据库连接
try {
    $db = get_db_connection();
} catch (PDOException $e) {
    error_log("数据库连接测试失败: " . $e->getMessage());
}
