<?php
/**
 * 网站头部模板
 */
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' . SITE_NAME : SITE_NAME; ?></title>
    <meta name="description" content="<?php echo isset($page_description) ? $page_description : SITE_DESCRIPTION; ?>">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <div class="logo">
                <a href="<?php echo BASE_URL; ?>">
                    <h1><?php echo SITE_NAME; ?></h1>
                </a>
                <p><?php echo SITE_DESCRIPTION; ?></p>
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="<?php echo BASE_URL; ?>" <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'class="active"' : ''; ?>>首页</a></li>
                    <?php
                    // 获取所有分类
                    $categories = get_all_categories();
                    foreach ($categories as $category) {
                        echo '<li><a href="' . BASE_URL . '/category.php?id=' . $category['id'] . '" ' . (isset($_GET['id']) && $_GET['id'] == $category['id'] ? 'class="active"' : '') . '>' . $category['name'] . '</a></li>';
                    }
                    ?>
                </ul>
            </nav>
            
            <div class="search-form">
                <form action="<?php echo BASE_URL; ?>/index.php" method="get">
                    <input type="text" name="s" placeholder="搜索文章..." value="<?php echo isset($_GET['s']) ? htmlspecialchars($_GET['s']) : ''; ?>">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>
        </div>
    </header>
