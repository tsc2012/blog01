<?php
/**
 * 网站侧边栏模板
 */
?>
    <aside class="sidebar">
        <div class="widget search-widget">
            <h3>搜索</h3>
            <form action="<?php echo BASE_URL; ?>/index.php" method="get">
                <input type="text" name="s" placeholder="搜索文章..." value="<?php echo isset($_GET['s']) ? htmlspecialchars($_GET['s']) : ''; ?>">
                <button type="submit"><i class="fas fa-search"></i></button>
            </form>
        </div>
        
        <div class="widget categories-widget">
            <h3>文章分类</h3>
            <ul>
                <?php
                // 获取所有分类
                $categories = get_all_categories();
                foreach ($categories as $category) {
                    // 获取分类下的文章数量
                    $post_count = get_total_posts($category['id']);
                    echo '<li><a href="' . BASE_URL . '/category.php?id=' . $category['id'] . '">' . $category['name'] . ' <span class="count">(' . $post_count . ')</span></a></li>';
                }
                ?>
            </ul>
        </div>
        
        <div class="widget recent-posts-widget">
            <h3>最新文章</h3>
            <ul>
                <?php
                // 获取最新的5篇文章
                $recent_posts = get_all_posts(5);
                foreach ($recent_posts as $post) {
                    echo '<li>';
                    echo '<a href="' . BASE_URL . '/article.php?id=' . $post['id'] . '">' . $post['title'] . '</a>';
                    echo '<span class="post-date">' . format_datetime($post['created_at'], 'Y-m-d') . '</span>';
                    echo '</li>';
                }
                ?>
            </ul>
        </div>
        
        <div class="widget tags-widget">
            <h3>热门标签</h3>
            <div class="tags-cloud">
                <?php
                // 模拟标签数据
                $tags = ['PHP', 'MySQL', 'JavaScript', 'HTML', 'CSS', 'WordPress', '前端开发', '后端开发', 'Web开发', '编程'];
                foreach ($tags as $tag) {
                    $font_size = rand(12, 20); // 随机字体大小
                    echo '<a href="#" style="font-size: ' . $font_size . 'px;">' . $tag . '</a>';
                }
                ?>
            </div>
        </div>
    </aside>
