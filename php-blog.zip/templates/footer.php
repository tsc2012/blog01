<?php
/**
 * 网站底部模板
 */
?>
    <footer class="site-footer">
        <div class="container">
            <div class="footer-widgets">
                <div class="widget about-widget">
                    <h3>关于我们</h3>
                    <p><?php echo SITE_DESCRIPTION; ?></p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-weixin"></i></a>
                        <a href="#"><i class="fab fa-weibo"></i></a>
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                
                <div class="widget categories-widget">
                    <h3>文章分类</h3>
                    <ul>
                        <?php
                        // 获取所有分类
                        $categories = get_all_categories();
                        foreach ($categories as $category) {
                            echo '<li><a href="' . BASE_URL . '/category.php?id=' . $category['id'] . '">' . $category['name'] . '</a></li>';
                        }
                        ?>
                    </ul>
                </div>
                
                <div class="widget recent-posts-widget">
                    <h3>最新文章</h3>
                    <ul>
                        <?php
                        // 获取最新的5篇文章
                        $recent_posts = get_all_posts(5);
                        foreach ($recent_posts as $post) {
                            echo '<li><a href="' . BASE_URL . '/article.php?id=' . $post['id'] . '">' . $post['title'] . '</a></li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. 保留所有权利.</p>
                <p class="admin-link"><a href="<?php echo BASE_URL; ?>/admin/login.php">管理员登录</a></p>
            </div>
        </div>
    </footer>
    
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
