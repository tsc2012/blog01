/**
 * PHP博客系统前端脚本
 */

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 移动端菜单切换
    const menuToggle = document.getElementById('menu-toggle');
    const mainNav = document.querySelector('.main-nav ul');
    
    if (menuToggle && mainNav) {
        menuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('show');
        });
    }
    
    // 图片懒加载
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver(function(entries, observer) {
            entriesries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    imageObserverserver.unobserve(img);
                }
            });
        });
        
        lazyImages.forEach(function(img) {
            imageObserver.observe(img);
        });
    }
    
    // 平滑滚动
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // 搜索框自动完成
    const searchInput = document.querySelector('input[name="s"]');
    
    if (searchInput) {
        searchInput.addEventListener('input', debounce(function() {
            const searchTerm = this.value.trim();
            
            if (searchTerm.length > 2) {
                // 模拟搜索建议
                console.log('Searching for:', searchTerm);
                // 实际应用中这里应该发送AJAX请求获取搜索建议
            }
        }, 300));
    }
    
    // 评论表单验证
    const commentForm = document.querySelector('.comment-form');
    
    if (commentForm) {
        commentForm.addEventListener('submit', function(e) {
            let isValid = true;
            
            // 验证姓名
            const nameInput = document.getElementById('name');
            if (!nameInput.value.trim()) {
                isValid = false;
                showError(nameInput, '请输入您的姓名');
            } else {
                hideError(nameInput);
            }
            
            // 验证邮箱
            const emailInput = document.getElementById('email');
            if (!emailInput.value.trim()) {
                isValid = false;
                showError(emailInput, '请输入您的邮箱');
            } else if (!isValidEmail(emailInput.value.trim())) {
                isValid = false;
                showError(emailInput, '请输入有效的邮箱地址');
            } else {
                hideError(emailInput);
            }
            
            // 验证评论内容
            const contentInput = document.getElementById('content');
            if (!contentInput.value.trim()) {
                isValid = false;
                showError(contentInput, '请输入评论内容');
            } else {
                hideError(contentInput);
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    }
    
    // 显示错误信息
    function showError(input, message) {
        const formGroup = input.closest('.form-group');
        let errorElement = formGroup.querySelector('.error-message');
        
        if (!errorElement) {
            errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            formGroup.appendChild(errorElement);
        }
        
        errorElement.textContent = message;
        input.classList.add('error');
    }
    
    // 隐藏错误信息
    function hideError(input) {
        const formGroup = input.closest('.form-group');
        const errorElement = formGroup.querySelector('.error-message');
        
        if (errorElement) {
            errorElement.remove();
        }
        
        input.classList.remove('error');
    }
    
    // 验证邮箱格式
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // 防抖函数
    function debounce(func, wait) {
        let timeout;
        return function() {
            const context = this;
            const args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                func.apply(context, args);
            }, wait);
        };
    }
    
    // 显示消息提示
    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // 添加动画
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // 自动关闭
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
    
    // 检查URL参数中的消息
    const urlParams = new URLSearchParams(window.location.search);
    const message = urlParams.get('message');
    const messageType = urlParams.get('message_type') || 'success';
    
    if (message) {
        showNotification(message, messageType);
    }
});
