<?php
/**
 * 评论管理页面
 */

require_once 'includes/auth.php';
require_once '../includes/comment_functions.php';
require_once '../includes/functions.php';

// 检查是否登录
admin_auth_middleware('manage_comments');

// 处理评论操作
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$message = '';
$message_type = 'success';

switch ($action) {
    case 'edit':
        // 编辑评论
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('comments.php');
        }
        
        $comment_id = intval($_GET['id']);
        $comment = get_comment_by_id($comment_id);
        
        if (!$comment) {
            redirect('comments.php');
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 准备评论数据
            $comment_data = [
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'website' => $_POST['website'],
                'content' => $_POST['content'],
                'status' => $_POST['status']
            ];
            
            // 更新评论
            $db = get_db_connection();
            $stmt = $db->prepare("UPDATE comments SET 
                                name = :name, 
                                email = :email, 
                                website = :website, 
                                content = :content, 
                                status = :status 
                                WHERE id = :id");
            
            $stmt->bindParam(':name', $comment_data['name'], PDO::PARAM_STR);
            $stmt->bindParam(':email', $comment_data['email'], PDO::PARAM_STR);
            $stmt->bindParam(':website', $comment_data['website'], PDO::PARAM_STR);
            $stmt->bindParam(':content', $comment_data['content'], PDO::PARAM_STR);
            $stmt->bindParam(':status', $comment_data['status'], PDO::PARAM_STR);
            $stmt->bindParam(':id', $comment_id, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                $message = '评论更新成功！';
                // 刷新评论数据
                $comment = get_comment_by_id($comment_id);
            } else {
                $message = '评论更新失败！';
                $message_type = 'error';
            }
        }
        break;
        
    case 'delete':
        // 删除评论
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('comments.php');
        }
        
        $comment_id = intval($_GET['id']);
        $comment = get_comment_by_id($comment_id);
        
        if ($comment) {
            // 删除评论
            if (delete_comment($comment_id)) {
                $message = '评论删除成功！';
            } else {
                $message = '评论删除失败！';
                $message_type = 'error';
            }
        }
        
        redirect('comments.php?status=' . $status . '&message=' . urlencode($message) . '&message_type=' . $message_type);
        break;
        
    case 'approve':
        // 批准评论
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('comments.php');
        }
        
        $comment_id = intval($_GET['id']);
        
        if (update_comment_status($comment_id, 'approved')) {
            $message = '评论已批准！';
        } else {
            $message = '评论批准失败！';
            $message_type = 'error';
        }
        
        redirect('comments.php?status=' . $status . '&message=' . urlencode($message) . '&message_type=' . $message_type);
        break;
        
    case 'unapprove':
        // 取消批准评论
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('comments.php');
        }
        
        $comment_id = intval($_GET['id']);
        
        if (update_comment_status($comment_id, 'pending')) {
            $message = '评论已设为待审核！';
        } else {
            $message = '操作失败！';
            $message_type = 'error';
        }
        
        redirect('comments.php?status=' . $status . '&message=' . urlencode($message) . '&message_type=' . $message_type);
        break;
        
    case 'mark_spam':
        // 标记为垃圾评论
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('comments.php');
        }
        
        $comment_id = intval($_GET['id']);
        
        if (update_comment_status($comment_id, 'spam')) {
            $message = '评论已标记为垃圾评论！';
        } else {
            $message = '操作失败！';
            $message_type = 'error';
        }
        
        redirect('comments.php?status=' . $status . '&message=' . urlencode($message) . '&message_type=' . $message_type);
        break;
        
    case 'list':
    default:
        // 评论列表
        // 获取当前页码
        $current_page = get_current_page();
        $offset = ($current_page - 1) * 20; // 每页显示20条评论
        
        // 获取评论总数
        $total_comments = get_total_comments(null, $status);
        
        // 获取评论列表
        $comments = get_all_comments($status, 20, $offset);
        
        // 处理消息
        if (isset($_GET['message'])) {
            $message = urldecode($_GET['message']);
            $message_type = isset($_GET['message_type']) ? $_GET['message_type'] : 'success';
        }
        break;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>评论管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        
        .admin-header {
            background-color: #2196F3;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-header h1 {
            margin: 0;
            font-size: 24px;
        }
        
        .admin-header a {
            color: #fff;
            text-decoration: none;
        }
        
        .admin-nav {
            background-color: #333;
            color: #fff;
        }
        
        .admin-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        
        .admin-nav li {
            margin: 0;
        }
        
        .admin-nav a {
            display: block;
            padding: 15px 20px;
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .admin-nav a:hover, .admin-nav a.active {
            background-color: #2196F3;
        }
        
        .admin-content {
            padding: 20px;
            min-height: calc(100vh - 180px);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .page-title {
            color: #333;
            margin-top: 0;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .btn {
            display: inline-block;
            padding: 8px 15px;
            background-color: #2196F3;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: #0b7dda;
        }
        
        .btn-success {
            background-color: #4CAF50;
        }
        
        .btn-success:hover {
            background-color: #45a049;
        }
        
        .btn-danger {
            background-color: #f44336;
        }
        
        .btn-danger:hover {
            background-color: #d32f2f;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .btn-warning {
            background-color: #ff9800;
        }
        
        .btn-warning:hover {
            background-color: #e68a00;
        }
        
        .table-container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-top: 20px;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th, .data-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .data-table th {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #333;
        }
        
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            max-width: 800px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .form-select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            background-color: #fff;
        }
        
        .form-textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            min-height: 150px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .admin-footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 15px 0;
        }
        
        .status-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-approved {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-spam {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .comment-filters {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .filter-group {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .filter-label {
            font-weight: bold;
            color: #333;
        }
        
        .filter-options {
            display: flex;
            gap: 5px;
        }
        
        .filter-option {
            padding: 5px 10px;
            background-color: #f0f0f0;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .filter-option:hover, .filter-option.active {
            background-color: #2196F3;
            color: #fff;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        
        .pagination a, .pagination span {
            display: inline-block;
            padding: 8px 15px;
            margin: 0 5px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #333;
        }
        
        .pagination a:hover {
            background-color: #f5f5f5;
        }
        
        .pagination span.current {
            background-color: #2196F3;
            color: #fff;
            border-color: #2196F3;
        }
        
        .comment-content {
            white-space: pre-line;
            line-height: 1.6;
        }
        
        .comment-meta {
            color: #666;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <h1><a href="index.php"><?php echo SITE_NAME; ?> 管理后台</a></h1>
        <div class="user-menu">
            <span>欢迎回来，<?php echo get_current_admin()['username']; ?></span> | 
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> 退出</a>
        </div>
    </header>
    
    <nav class="admin-nav">
        <div class="container">
            <ul>
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> 仪表盘</a></li>
                <li><a href="articles.php"><i class="fas fa-file-alt"></i> 文章管理</a></li>
                <li><a href="categories.php"><i class="fas fa-folder"></i> 分类管理</a></li>
                <li><a href="comments.php" class="active"><i class="fas fa-comments"></i> 评论管理</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> 用户管理</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="admin-content">
        <div class="container">
            <?php if ($message) : ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($action === 'list') : ?>
                <h2 class="page-title">
                    评论管理
                    <span class="count">(共 <?php echo $total_comments; ?> 条评论)</span>
                </h2>
                
                <div class="comment-filters">
                    <div class="filter-group">
                        <span class="filter-label">状态:</span>
                        <div class="filter-options">
                            <a href="comments.php?status=all" class="filter-option <?php echo $status === 'all' ? 'active' : ''; ?>">全部</a>
                            <a href="comments.php?status=pending" class="filter-option <?php echo $status === 'pending' ? 'active' : ''; ?>">待审核 (<?php echo get_total_comments(null, 'pending'); ?>)</a>
                            <a href="comments.php?status=approved" class="filter-option <?php echo $status === 'approved' ? 'active' : ''; ?>">已批准 (<?php echo get_total_comments(null, 'approved'); ?>)</a>
                            <a href="comments.php?status=spam" class="filter-option <?php echo $status === 'spam' ? 'active' : ''; ?>">垃圾评论 (<?php echo get_total_comments(null, 'spam'); ?>)</a>
                        </div>
                    </div>
                </div>
                
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>评论内容</th>
                                <th>评论者</th>
                                <th>文章</th>
                                <th>状态</th>
                                <th>时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($comments)) : ?>
                                <?php foreach ($comments as $comment) : ?>
                                    <tr>
                                        <td><?php echo $comment['id']; ?></td>
                                        <td>
                                            <div class="comment-content"><?php echo nl2br(htmlspecialspecialchars(substr($comment['content'], 0, 100) . (strlen($comment['content']) > 100 ? '...' : ''))); ?></div>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialspecialchars($comment['name']); ?><br>
                                            <a href="mailto:<?php echo htmlspecialspecialchars($comment['email']); ?>"><?php echo htmlspecialspecialchars($comment['email']); ?></a><br>
                                            <?php if (!empty($comment['website'])) : ?>
                                                <a href="<?php echo htmlspecialspecialchars($comment['website']); ?>" target="_blank" rel="noopener noreferrer"><?php echo parse_url($comment['website'], PHP_URL_HOST); ?></a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (!empty($comment['post_title'])) : ?>
                                                <a href="../article.php?id=<?php echo $comment['post_id']; ?>" target="_blank"><?php echo htmlspecialspecialchars($comment['post_title']); ?></a>
                                            <?php else : ?>
                                                <span class="text-muted">文章已删除</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><span class="status-badge status-<?php echo $comment['status']; ?>"><?php echo ucfirst($comment['status']); ?></span></td>
                                        <td><?php echo format_datetime($comment['created_at'], 'Y-m-d H:i'); ?></td>
                                        <td class="action-buttons">
                                            <a href="comments.php?action=edit&id=<?php echo $comment['id']; ?>" class="btn btn-sm"><i class="fas fa-edit"></i> 编辑</a>
                                            <?php if ($comment['status'] !== 'approved') : ?>
                                                <a href="comments.php?action=approve&id=<?php echo $comment['id']; ?>&status=<?php echo $status; ?>" class="btn btn-sm btn-success"><i class="fas fa-check"></i> 批准</a>
                                            <?php else : ?>
                                                <a href="comments.php?action=unapprove&id=<?php echo $comment['id']; ?>&status=<?php echo $status; ?>" class="btn btn-sm btn-warning"><i class="fas fa-clock"></i> 待审</a>
                                            <?php endif; ?>
                                            <?php if ($comment['status'] !== 'spam') : ?>
                                                <a href="comments.php?action=mark_spam&id=<?php echo $comment['id']; ?>&status=<?php echo $status; ?>" class="btn btn-sm btn-warning"><i class="fas fa-exclamation-triangle"></i> 垃圾</a>
                                            <?php endif; ?>
                                            <a href="comments.php?action=delete&id=<?php echo $comment['id']; ?>&status=<?php echo $status; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定要删除这条评论吗？');"><i class="fas fa-trash"></i> 删除</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="7" style="text-align: center;">暂无评论</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php
                // 显示分页
                $total_pages = ceil($total_comments / 20);
                if ($total_pages > 1) {
                    echo get_pagination_links($total_comments, 20, $current_page, 'comments.php?status=' . $status);
                }
                ?>
                
            <?php elseif ($action === 'edit') : ?>
                <h2 class="page-title">
                    编辑评论
                    <a href="comments.php?status=<?php echo $status; ?>" class="btn"><i class="fas fa-arrow-left"></i> 返回列表</a>
                </h2>
                
                <div class="form-container">
                    <form action="comments.php?action=edit&id=<?php echo $comment_id; ?>&status=<?php echo $status; ?>" method="post">
                        <div class="form-group">
                            <label for="name">评论者姓名 <span class="required">*</span></label>
                            <input type="text" id="name" name="name" class="form-control" required value="<?php echo htmlspecialspecialchars($comment['name']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="email">邮箱 <span class="required">*</span></label>
                            <input type="email" id="email" name="email" class="form-control" required value="<?php echo htmlspecialspecialchars($comment['email']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="website">网站</label>
                            <input type="url" id="website" name="website" class="form-control" value="<?php echo htmlspecialspecialchars($comment['website']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="status">状态 <span class="required">*</span></label>
                            <select id="status" name="status" class="form-select" required>
                                <option value="pending" <?php echo $comment['status'] == 'pending' ? 'selected' : ''; ?>>待审核</option>
                                <option value="approved" <?php echo $comment['status'] == 'approved' ? 'selected' : ''; ?>>已批准</option>
                                <option value="spam" <?php echo $comment['status'] == 'spam' ? 'selected' : ''; ?>>垃圾评论</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="content">评论内容 <span class="required">*</span></label>
                            <textarea id="content" name="content" class="form-textarea" required><?php echo htmlspecialspecialchars($comment['content']); ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>评论时间</label>
                            <p><?php echo format_datetime($comment['created_at'], 'Y-m-d H:i:s'); ?></p>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> 保存</button>
                            <a href="comments.php?status=<?php echo $status; ?>" class="btn" style="margin-left: 10px;">取消</a>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </main>
    
    <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> 管理后台 - 版权所有</p>
    </footer>
</body>
</html>
