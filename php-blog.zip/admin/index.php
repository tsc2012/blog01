<?php
/**
 * 管理后台首页
 */

require_once 'includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/comment_functions.php';

// 检查是否登录
admin_auth_middleware();

// 获取当前登录管理员信息
$admin = get_current_admin();

// 获取统计数据
$total_posts = get_total_posts();
$total_categories = count(get_all_categories());
$total_comments = get_total_comments(null, 'all');
$pending_comments = get_total_comments(null, 'pending');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        
        .admin-header {
            background-color: #2196F3;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-header h1 {
            margin: 0;
            font-size: 24px;
        }
        
        .admin-header a {
            color: #fff;
            text-decoration: none;
        }
        
        .admin-nav {
            background-color: #333;
            color: #fff;
        }
        
        .admin-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        
        .admin-nav li {
            margin: 0;
        }
        
        .admin-nav a {
            display: block;
            padding: 15px 20px;
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .admin-nav a:hover, .admin-nav a.active {
            background-color: #2196F3;
        }
        
        .admin-content {
            padding: 20px;
            min-height: calc(100vh - 180px);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: #2196F3;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 20px;
        }
        
        .stat-info h3 {
            margin: 0;
            font-size: 28px;
            color: #333;
        }
        
        .stat-info p {
            margin: 5px 0 0;
            color: #666;
        }
        
        .recent-activity {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .recent-activity h2 {
            margin-top: 0;
            color: #333;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        
        .activity-list {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        .activity-list li {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: center;
        }
        
        .activity-list li:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #f0f0f0;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        
        .activity-info {
            flex: 1;
        }
        
        .activity-info p {
            margin: 0;
            color: #333;
        }
        
        .activity-info span {
            color: #999;
            font-size: 12px;
        }
        
        .admin-footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 15px 0;
        }
        
        .btn {
            display: inline-block;
            padding: 8px 15px;
            background-color: #2196F3;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: #0b7dda;
        }
        
        .btn-success {
            background-color: #4CAF50;
        }
        
        .btn-success:hover {
            background-color: #45a049;
        }
        
        .btn-danger {
            background-color: #f44336;
        }
        
        .btn-danger:hover {
            background-color: #d32f2f;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .welcome-message {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        
        .welcome-message h2 {
            margin-top: 0;
            color: #333;
        }
        
        .welcome-message p {
            color: #666;
        }
        
        .quick-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <h1><a href="index.php"><?php echo SITE_NAME; ?> 管理后台</a></h1>
        <div class="user-menu">
            <span>欢迎回来，<?php echo $admin['username']; ?></span> | 
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> 退出</a>
        </div>
    </header>
    
    <nav class="admin-nav">
        <div class="container">
            <ul>
                <li><a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> 仪表盘</a></li>
                <li><a href="articles.php"><i class="fas fa-file-alt"></i> 文章管理</a></li>
                <li><a href="categories.php"><i class="fas fa-folder"></i> 分类管理</a></li>
                <li><a href="comments.php"><i class="fas fa-comments"></i> 评论管理</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> 用户管理</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="admin-content">
        <div class="container">
            <div class="welcome-message">
                <h2>欢迎回来，<?php echo $admin['username']; ?>！</h2>
                <p>今天是 <?php echo date('Y年m月d日'); ?>，这是您的网站概览。</p>
                <div class="quick-actions">
                    <a href="articles.php?action=add" class="btn btn-success"><i class="fas fa-plus"></i> 新建文章</a>
                    <a href="categories.php?action=add" class="btn"><i class="fas fa-folder-plus"></i> 新建分类</a>
                </div>
            </div>
            
            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $total_posts; ?></h3>
                        <p>文章总数</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-folder"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $total_categories; ?></h3>
                        <p>分类总数</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $total_comments; ?></h3>
                        <p>评论总数</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $pending_comments; ?></h3>
                        <p>待审核评论</p>
                    </div>
                </div>
            </div>
            
            <div class="recent-activity">
                <h2>最近活动</h2>
                <ul class="activity-list">
                    <li>
                        <div class="activity-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="activity-info">
                            <p>发布了新文章 <a href="#">欢迎使用PHP博客系统</a></p>
                            <span>今天 10:30</span>
                        </div>
                    </li>
                    <li>
                        <div class="activity-icon">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <div class="activity-info">
                            <p>创建了新用户 <a href="#">admin</a></p>
                            <span>昨天 15:45</span>
                        </div>
                    </li>
                    <li>
                        <div class="activity-icon">
                            <i class="fas fa-folder-plus"></i>
                        </div>
                        <div class="activity-info">
                            <p>创建了新分类 <a href="#">技术</a></p>
                            <span>2023-06-10 09:15</span>
                        </div>
                    </li>
                    <li>
                        <div class="activity-icon">
                            <i class="fas fa-comment"></i>
                        </div>
                        <div class="activity-info">
                            <p>审核通过了评论 <a href="#">这是一条评论</a></p>
                            <span>2023-06-09 14:20</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </main>
    
    <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> 管理后台 - 版权所有</p>
    </footer>
</body>
</html>
