<?php
/**
 * 管理员退出登录
 */

require_once 'includes/auth.php';

// 执行退出登录
admin_logout();

// 重定向到登录页面
redirect('login.php');
?>
