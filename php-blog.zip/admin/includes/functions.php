<?php
/**
 * 管理端专属函数
 * 包含管理后台使用的各种功能
 */

require_once '../../includes/functions.php';
require_once 'auth.php';

/**
 * 添加文章
 * @param array $data 文章数据
 * @return int|false 文章ID或false
 */
function add_post($data) {
    $db = get_db_connection();
    
    // 验证数据
    if (empty($data['title']) || empty($data['content']) || empty($data['category_id'])) {
        return false;
    }
    
    // 准备数据
    $title = clean_input($data['title']);
    $slug = create_slug($title);
    $content = $data['content']; // 不清理HTML内容
    $category_id = intval($data['category_id']);
    $author_id = $_SESSION['admin_id'];
    $status = isset($data['status']) ? $data['status'] : 'draft';
    $featured_image = isset($data['featured_image']) ? $data['featured_image'] : '';
    $created_at = date('Y-m-d H:i:s');
    $updated_at = $created_at;
    
    // 检查分类是否存在
    $stmt = $db->prepare("SELECT id FROM categories WHERE id = :category_id");
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->execute();
    
    if (!$stmt->fetch()) {
        return false;
    }
    
    // 插入文章
    $stmt = $db->prepare("INSERT INTO posts (title, slug, content, category_id, author_id, status, featured_image, created_at, updated_at) 
                        VALUES (:title, :slug, :content, :category_id, :author_id, :status, :featured_image, :created_at, :updated_at)");
    
    $stmt->bindParam(':title', $title, PDO::PARAM_STR);
    $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
    $stmt->bindParam(':content', $content, PDO::PARAM_STR);
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->bindParam(':author_id', $author_id, PDO::PARAM_INT);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':featured_image', $featured_image, PDO::PARAM_STR);
    $stmt->bindParam(':created_at', $created_at, PDO::PARAM_STR);
    $stmt->bindParam(':updated_at', $updated_at, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        return $db->lastInsertId();
    }
    
    return false;
}

/**
 * 更新文章
 * @param int $id 文章ID
 * @param array $data 文章数据
 * @return bool 是否成功
 */
function update_post($id, $data) {
    $db = get_db_connection();
    
    // 验证数据
    if (empty($data['title']) || empty($data['content']) || empty($data['category_id'])) {
        return false;
    }
    
    // 准备数据
    $title = clean_input($data['title']);
    $slug = create_slug($title);
    $content = $data['content']; // 不清理HTML内容
    $category_id = intval($data['category_id']);
    $status = isset($data['status']) ? $data['status'] : 'draft';
    $featured_image = isset($data['featured_image']) ? $data['featured_image'] : '';
    $updated_at = date('Y-m-d H:i:s');
    
    // 检查文章是否存在
    $stmt = $db->prepare("SELECT id FROM posts WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    if (!$stmt->fetch()) {
        return false;
    }
    
    // 检查分类是否存在
    $stmt = $db->prepare("SELECT id FROM categories WHERE id = :category_id");
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->execute();
    
    if (!$stmt->fetch()) {
        return false;
    }
    
    // 更新文章
    $stmt = $db->prepare("UPDATE posts SET 
                        title = :title, 
                        slug = :slug, 
                        content = :content, 
                        category_id = :category_id, 
                        status = :status, 
                        featured_image = :featured_image, 
                        updated_at = :updated_at 
                        WHERE id = :id");
    
    $stmt->bindParam(':title', $title, PDO::PARAM_STR);
    $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
    $stmt->bindParam(':content', $content, PDO::PARAM_STR);
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->bindParam(':featured_image', $featured_image, PDO::PARAM_STR);
    $stmt->bindParam(':updated_at', $updated_at, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    
    return $stmt->execute();
}

/**
 * 删除文章
 * @param int $id 文章ID
 * @return bool 是否成功
 */
function delete_post($id) {
    $db = get_db_connection();
    
    // 先删除相关评论
    $stmt = $db->prepare("DELETE FROM comments WHERE post_id = :post_id");
    $stmt->bindParam(':post_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    // 删除文章
    $stmt = $db->prepare("DELETE FROM posts WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    return $stmt->execute();
}

/**
 * 添加分类
 * @param array $data 分类数据
 * @return int|false 分类ID或false
 */
function add_category($data) {
    $db = get_db_connection();
    
    // 验证数据
    if (empty($data['name'])) {
        return false;
    }
    
    // 准备数据
    $name = clean_input($data['name']);
    $slug = create_slug($name);
    $description = isset($data['description']) ? clean_input($data['description']) : '';
    $created_at = date('Y-m-d H:i:s');
    $updated_at = $created_at;
    
    // 检查分类是否已存在
    $stmt = $db->prepare("SELECT id FROM categories WHERE name = :name OR slug = :slug");
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
    $stmt->execute();
    
    if ($stmt->fetch()) {
        return false;
    }
    
    // 插入分类
    $stmt = $db->prepare("INSERT INTO categories (name, slug, description, created_at, updated_at) 
                        VALUES (:name, :slug, :description, :created_at, :updated_at)");
    
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
    $stmt->bindParam(':description', $description, PDO::PARAM_STR);
    $stmt->bindParam(':created_at', $created_at, PDO::PARAM_STR);
    $stmt->bindParam(':updated_at', $updated_at, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        return $db->lastInsertId();
    }
    
    return false;
}

/**
 * 更新分类
 * @param int $id 分类ID
 * @param array $data 分类数据
 * @return bool 是否成功
 */
function update_category($id, $data) {
    $db = get_db_connection();
    
    // 验证数据
    if (empty($data['name'])) {
        return false;
    }
    
    // 准备数据
    $name = clean_input($data['name']);
    $slug = create_slug($name);
    $description = isset($data['description']) ? clean_input($data['description']) : '';
    $updated_at = date('Y-m-d H:i:s');
    
    // 检查分类是否存在
    $stmt = $db->prepare("SELECT id FROM categories WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    if (!$stmt->fetch()) {
        return false;
    }
    
    // 检查分类是否已存在（排除当前分类）
    $stmt = $db->prepare("SELECT id FROM categories WHERE (name = :name OR slug = :slug) AND id != :id");
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->fetch()) {
        return false;
    }
    
    // 更新分类
    $stmt = $db->prepare("UPDATE categories SET 
                        name = :name, 
                        slug = :slug, 
                        description = :description, 
                        updated_at = :updated_at 
                        WHERE id = :id");
    
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
    $stmt->bindParam(':description', $description, PDO::PARAM_STR);
    $stmt->bindParam(':updated_at', $updated_at, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    
    return $stmt->execute();
}

/**
 * 删除分类
 * @param int $id 分类ID
 * @return bool 是否成功
 */
function delete_category($id) {
    $db = get_db_connection();
    
    // 检查是否有文章使用此分类
    $stmt = $db->prepare("SELECT id FROM posts WHERE category_id = :category_id");
    $stmt->bindParam(':category_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->fetch()) {
        return false; // 有文章使用此分类，不允许删除
    }
    
    // 删除分类
    $stmt = $db->prepare("DELETE FROM categories WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    return $stmt->execute();
}

/**
 * 创建URL友好的slug
 * @param string $string 原始字符串
 * @return string slug
 */
function create_slug($string) {
    // 转换为小写
    $slug = strtolower($string);
    
    // 替换特殊字符
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
    
    // 去除首尾的横线
    $slug = trim($slug, '-');
    
    // 如果slug为空，使用随机字符串
    if (empty($slug)) {
        $slug = generate_random_string(10);
    }
    
    return $slug;
}

/**
 * 获取管理员列表
 * @return array 管理员列表
 */
function get_all_admins() {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT id, username, email, created_at, last_login FROM admins ORDER BY created_at DESC");
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * 添加管理员
 * @param array $data 管理员数据
 * @return int|false 管理员ID或false
 */
function add_admin($data) {
    $db = get_db_connection();
    
    // 验证数据
    if (empty($data['username']) || empty($data['email']) || empty($data['password'])) {
        return false;
    }
    
    // 检查用户名和邮箱是否已存在
    $stmt = $db->prepare("SELECT id FROM admins WHERE username = :username OR email = :email");
    $stmt->bindParam(':username', $data['username'], PDO::PARAM_STR);
    $stmt->bindParam(':email', $data['email'], PDO::PARAM_STR);
    $stmt->execute();
    
    if ($stmt->fetch()) {
        return false;
    }
    
    // 准备数据
    $username = clean_input($data['username']);
    $email = filter_var($data['email'], FILTER_VALIDATE_EMAIL);
    $password = password_hash($data['password'], PASSWORD_DEFAULT);
    $created_at = date('Y-m-d H:i:s');
    $last_login = null;
    
    // 检查邮箱格式
    if (!$email) {
        return false;
    }
    
    // 插入管理员
    $stmt = $db->prepare("INSERT INTO admins (username, email, password, created_at, last_login) 
                        VALUES (:username, :email, :password, :created_at, :last_login)");
    
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':password', $password, PDO::PARAM_STR);
    $stmt->bindParam(':created_at', $created_at, PDO::PARAM_STR);
    $stmt->bindParam(':last_login', $last_login, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        $admin_id = $db->lastInsertId();
        
        // 添加默认权限
        add_admin_permissions($admin_id, ['manage_posts', 'manage_categories', 'manage_comments']);
        
        return $admin_id;
    }
    
    return false;
}

/**
 * 更新管理员
 * @param int $id 管理员ID
 * @param array $data 管理员数据
 * @return bool 是否成功
 */
function update_admin($id, $data) {
    $db = get_db_connection();
    
    // 验证数据
    if (empty($data['username']) || empty($data['email'])) {
        return false;
    }
    
    // 检查管理员是否存在
    $stmt = $db->prepare("SELECT id FROM admins WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    if (!$stmt->fetch()) {
        return false;
    }
    
    // 检查用户名和邮箱是否已存在（排除当前管理员）
    $stmt = $db->prepare("SELECT id FROM admins WHERE (username = :username OR email = :email) AND id != :id");
    $stmt->bindParam(':username', $data['username'], PDO::PARAM_STR);
    $stmt->bindParam(':email', $data['email'], PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->fetch()) {
        return false;
    }
    
    // 准备数据
    $username = clean_input($data['username']);
    $email = filter_var($data['email'], FILTER_VALIDATE_EMAIL);
    
    // 检查邮箱格式
    if (!$email) {
        return false;
    }
    
    // 如果有密码，则更新密码
    if (!empty($data['password'])) {
        $password = password_hash($data['password'], PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE admins SET username = :username, email = :email, password = :password WHERE id = :id");
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);
    } else {
        $stmt = $db->prepare("UPDATE admins SET username = :username, email = :email WHERE id = :id");
    }
    
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    
    return $stmt->execute();
}

/**
 * 删除管理员
 * @param int $id 管理员ID
 * @return bool 是否成功
 */
function delete_admin($id) {
    $db = get_db_connection();
    
    // 不允许删除当前登录的管理员
    if ($id == $_SESSION['admin_id']) {
        return false;
    }
    
    // 先删除权限关联
    $stmt = $db->prepare("DELETE FROM admin_permissions WHERE admin_id = :admin_id");
    $stmt->bindParam(':admin_id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    // 删除管理员
    $stmt = $db->prepare("DELETE FROM admins WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    return $stmt->execute();
}

/**
 * 添加管理员权限
 * @param int $admin_id 管理员ID
 * @param array $permissions 权限列表
 */
function add_admin_permissions($admin_id, $permissions) {
    $db = get_db_connection();
    
    // 获取所有权限
    $stmt = $db->prepare("SELECT id, name FROM permissions");
    $stmt->execute();
    $all_permissions = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // 插入权限关联
    foreach ($permissions as $permission) {
        if (isset($all_permissions[$permission])) {
            $permission_id = $all_permissions[$permission];
            
            $stmt = $db->prepare("INSERT INTO admin_permissions (admin_id, permission_id) VALUES (:admin_id, :permission_id)");
            $stmt->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);
            $stmt->bindParam(':permission_id', $permission_id, PDO::PARAM_INT);
            $stmt->execute();
        }
    }
}
