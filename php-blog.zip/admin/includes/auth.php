<?php
/**
 * 管理员认证文件
 * 包含管理员登录、注销和权限检查等功能
 */

session_start();
require_once '../../includes/db.php';

/**
 * 检查管理员是否已登录
 * @return bool 是否已登录
 */
function is_admin_logged_in() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

/**
 * 管理员登录
 * @param string $username 用户名
 * @param string $password 密码
 * @return bool|array 成功返回用户数据，失败返回false
 */
function admin_login($username, $password) {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM admins WHERE username = :username LIMIT 1");
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch();
    
    if ($admin && password_verify($password, $admin['password'])) {
        // 设置会话
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['admin_email'] = $admin['email'];
        $_SESSION['last_login'] = date('Y-m-d H:i:s');
        
        // 更新最后登录时间
        update_last_login($admin['id']);
        
        return $admin;
    }
    
    return false;
}

/**
 * 管理员注销
 */
function admin_logout() {
    // 销毁会话
    $_SESSION = [];
    
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    session_destroy();
}

/**
 * 检查管理员权限
 * @param string $permission 权限名称
 * @return bool 是否有权限
 */
function has_permission($permission) {
    if (!is_admin_logged_in()) {
        return false;
    }
    
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT p.name FROM permissions p
                        JOIN admin_permissions ap ON p.id = ap.permission_id
                        WHERE ap.admin_id = :admin_id");
    $stmt->bindParam(':admin_id', $_SESSION['admin_id'], PDO::PARAM_INT);
    $stmt->execute();
    $permissions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    return in_array($permission, $permissions);
}

/**
 * 更新最后登录时间
 * @param int $admin_id 管理员ID
 */
function update_last_login($admin_id) {
    $db = get_db_connection();
    $stmt = $db->prepare("UPDATE admins SET last_login = :last_login WHERE id = :id");
    $last_login = date('Y-m-d H:i:s');
    $stmt->bindParam(':last_login', $last_login, PDO::PARAM_STR);
    $stmt->bindParam(':id', $admin_id, PDO::PARAM_INT);
    $stmt->execute();
}

/**
 * 获取当前登录管理员信息
 * @return array|null 管理员信息或null
 */
function get_current_admin() {
    if (!is_admin_logged_in()) {
        return null;
    }
    
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT id, username, email, created_at, last_login FROM admins WHERE id = :id");
    $stmt->bindParam(':id', $_SESSION['admin_id'], PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}

/**
 * 管理员权限检查中间件
 * @param string $permission 所需权限
 */
function admin_auth_middleware($permission = null) {
    if (!is_admin_logged_in()) {
        // 保存当前URL用于登录后跳转
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        redirect('../../admin/login.php');
    }
    
    if ($permission && !has_permission($permission)) {
        redirect('../../admin/index.php?error=permission_denied');
    }
}
