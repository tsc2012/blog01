<?php
/**
 * 分类管理页面
 */

require_once 'includes/auth.php';
require_once 'includes/functions.php';

// 检查是否登录
admin_auth_middleware('manage_categories');

// 处理分类操作
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$message = '';
$message_type = 'success';

switch ($action) {
    case 'add':
        // 添加分类
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 准备分类数据
            $category_data = [
                'name' => $_POST['name'],
                'description' => $_POST['description']
            ];
            
            // 添加分类
            $category_id = add_category($category_data);
            
            if ($category_id) {
                $message = '分类添加成功！';
                // 清空表单
                $_POST = [];
            } else {
                $message = '分类添加失败，分类名称名称可能已存在！';
                $message_type = 'error';
            }
        }
        break;
        
    case 'edit':
        // 编辑分类
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('categories.php');
        }
        
        $category_id = intval($_GET['id']);
        $category = get_category_by_id($category_id);
        
        if (!$category) {
            redirect('categories.php');
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 准备分类数据
            $category_data = [
                'name' => $_POST['name'],
                'description' => $_POST['description']
            ];
            
            // 更新分类
            if (update_category($category_id, $category_data)) {
                $message = '分类更新成功！';
                // 刷新分类数据
                $category = get_category_by_id($category_id);
            } else {
                $message = '分类更新失败，分类名称已存在！';
                $message_type = 'error';
            }
        }
        break;
        
    case 'delete':
        // 删除分类
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('categories.php');
        }
        
        $category_id = intval($_GET['id']);
        $category = get_category_by_id($category_id);
        
        if ($category) {
            // 删除分类
            if (delete_category($category_id)) {
                $message = '分类删除成功！';
            } else {
                $message = '分类删除失败，该分类下还有文章！';
                $message_type = 'error';
            }
        }
        
        redirect('categories.php?message=' . urlencode($message) . '&message_type=' . $message_type);
        break;
        
    case 'list':
    default:
        // 分类列表
        // 获取所有分类
        $categories = get_all_categories();
        
        // 处理消息
        if (isset($_GET['message'])) {
            $message = urldecode($_GET['message']);
            $message_type = isset($_GET['message_type']) ? $_GET['message_type'] : 'success';
        }
        break;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分类管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        
        .admin-header {
            background-color: #2196F3;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-header h1 {
            margin: 0;
            font-size: 24px;
        }
        
        .admin-header a {
            color: #fff;
            text-decoration: none;
        }
        
        .admin-nav {
            background-color: #333;
            color: #fff;
        }
        
        .admin-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        
        .admin-nav li {
            margin: 0;
        }
        
        .admin-nav a {
            display: block;
            padding: 15px 20px;
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .admin-nav a:hover, .admin-nav a.active {
            background-color: #2196F3;
        }
        
        .admin-content {
            padding: 20px;
            min-height: calc(100vh - 180px);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .page-title {
            color: #333;
            margin-top: 0;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .btn {
            display: inline-block;
            padding: 8px 15px;
            background-color: #2196F3;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: #0b7dda;
        }
        
        .btn-success {
            background-color: #4CAF50;
        }
        
        .btn-success:hover {
            background-color: #45a049;
        }
        
        .btn-danger {
            background-color: #f44336;
        }
        
        .btn-danger:hover {
            background-color: #d32f2f;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .table-container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-top: 20px;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th, .data-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .data-table th {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #333;
        }
        
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            max-width: 600px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .form-textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            min-height: 150px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .admin-footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 15px 0;
        }
        
        .post-count {
            display: inline-block;
            padding: 3px 8px;
            background-color: #f0f0f0;
            border-radius: 20px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <h1><a href="index.php"><?php echo SITE_NAME; ?> 管理后台</a></h1>
        <div class="user-menu">
            <span>欢迎回来，<?php echo get_current_admin()['username']; ?></span> | 
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> 退出</a>
        </div>
    </header>
    
    <nav class="admin-nav">
        <div class="container">
            <ul>
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> 仪表盘</a></li>
                <li><a href="articles.php"><i class="fas fa-file-alt"></i> 文章管理</a></li>
                <li><a href="categories.php" class="active"><i class="fas fa-folder"></i> 分类管理</a></li>
                <li><a href="comments.php"><i class="fas fa-comments"></i> 评论管理</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> 用户管理</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="admin-content">
        <div class="container">
            <?php if ($message) : ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($action === 'list') : ?>
                <h2 class="page-title">
                    分类管理
                    <a href="categories.php?action=add" class="btn btn-success"><i class="fas fa-plus"></i> 新建分类</a>
                </h2>
                
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>名称</th>
                                <th>描述</th>
                                <th>文章数量</th>
                                <th>创建时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($categories)) : ?>
                                <?php foreach ($categories as $category) : ?>
                                    <tr>
                                        <td><?php echo $category['id']; ?></td>
                                        <td><?php echo htmlspecialspecialchars($category['name']); ?></td>
                                        <td><?php echo htmlspecialspecialchars($category['description']); ?></td>
                                        <td>
                                            <?php
                                            $post_count = get_total_posts($category['id']);
                                            echo '<a href="../category.php?id=' . $category['id'] . '" target="_blank">' . $post_count . '</a>';
                                            ?>
                                        </td>
                                        <td><?php echo format_datetime($category['created_at'], 'Y-m-d'); ?></td>
                                        <td class="action-buttons">
                                            <a href="categories.php?action=edit&id=<?php echo $category['id']; ?>" class="btn btn-sm"><i class="fas fa-edit"></i> 编辑</a>
                                            <a href="categories.php?action=delete&id=<?php echo $category['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定要删除这个分类吗？删除前请请确保该分类下的所有文章文章！');"><i class="fas fa-trash"></i> 删除</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="6" style="text-align: center;">暂无分类</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
            <?php elseif ($action === 'add' || $action === 'edit') : ?>
                <h2 class="page-title">
                    <?php echo $action === 'add' ? '新建分类' : '编辑分类'; ?>
                    <a href="categories.php" class="btn"><i class="fas fa-arrow-left"></i> 返回列表</a>
                </h2>
                
                <div class="form-container">
                    <form action="<?php echo $action === 'add' ? 'categories.php?action=add' : 'categories.php?action=edit&id=' . $category_id; ?>" method="post">
                        <div class="form-group">
                            <label for="name">分类名称 <span class="required">*</span></label>
                            <input type="text" id="name" name="name" class="form-control" required value="<?php echo $action === 'edit' ? htmlspecialspecialchars($category['name']) : (isset($_POST['name']) ? htmlspecialspecialchars($_POST['name']) : ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="description">分类描述</label>
                            <textarea id="description" name="description" class="form-textarea"><?php echo $action === 'edit' ? htmlspecialspecialchars($category['description']) : (isset($_POST['description']) ? htmlspecialspecialchars($_POST['description']) : ''); ?></textarea>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> 保存</button>
                            <a href="categories.php" class="btn" style="margin-left: 10px;">取消</a>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </main>
    
    <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> 管理后台 - 版权所有</p>
    </footer>
</body>
</html>
