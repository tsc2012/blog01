<?php
/**
 * 用户管理页面
 */

require_once 'includes/auth.php';
require_once 'includes/functions.php';

// 检查是否登录
admin_auth_middleware('manage_users');

// 处理用户操作
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$message = '';
$message_type = 'success';

switch ($action) {
    case 'add':
        // 添加用户
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 验证密码
            if ($_POST['password'] !== $_POST['confirm_password']) {
                $message = '两次输入的密码不一致！';
                $message_type = 'error';
            } else {
                // 准备用户数据
                $user_data = [
                    'username' => $_POST['username'],
                    'email' => $_POST['email'],
                    'password' => $_POST['password']
                ];
                
                // 添加用户
                $user_id = add_admin($user_data);
                
                if ($user_id) {
                    $message = '用户添加成功！';
                    // 清空表单
                    $_POST = [];
                } else {
                    $message = '用户添加失败，用户名名或邮箱已已存在！';
                    $message_type = 'error';
                }
            }
        }
        break;
        
    case 'edit':
        // 编辑用户
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('users.php');
        }
        
        $user_id = intval($_GET['id']);
        $user = get_current_admin_by_id($user_id);
        
        if (!$user) {
            redirect('users.php');
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 准备用户数据
            $user_data = [
                'username' => $_POST['username'],
                'email' => $_POST['email']
            ];
            
            // 如果有密码，则添加到数据中
            if (!empty($_POST['password'])) {
                // 验证密码
                if ($_POST['password'] !== $_POST['confirm_password']) {
                    $message = '两次输入的密码不一致！';
                    $message_type = 'error';
                } else {
                    $user_data['password'] = $_POST['password'];
                }
            }
            
            // 更新用户
            if (empty($message) && update_admin($user_id, $user_data)) {
                $message = '用户更新成功！';
                // 刷新用户数据
                $user = get_current_admin_by_id($user_id);
            } elseif (empty($message)) {
                $message = '用户更新失败，用户名或邮箱已存在！';
                $message_type = 'error';
            }
        }
        break;
        
    case 'delete':
        // 删除用户
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            redirect('users.php');
        }
        
        $user_id = intval($_GET['id']);
        $user = get_current_admin_by_id($user_id);
        
        if ($user) {
            // 删除用户
            if (delete_admin($user_id)) {
                $message = '用户删除成功！';
            } else {
                $message = '用户删除失败，无法删除当前登录用户！';
                $message_type = 'error';
            }
        }
        
        redirect('users.php?message=' . urlencode($message) . '&message_type=' . $message_type);
        break;
        
    case 'list':
    default:
        // 用户列表
        // 获取所有用户
        $users = get_all_admins();
        
        // 处理消息
        if (isset($_GET['message'])) {
            $message = urldecode($_GET['message']);
            $message_type = isset($_GET['message_type']) ? $_GET['message_type'] : 'success';
        }
        break;
}

/**
 * 获取指定ID的管理员
 * @param int $id 管理员ID
 * @return array|null 管理员数据或null
 */
function get_current_admin_by_id($id) {
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT id, username, email, created_at, last_login FROM admins WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        
        .admin-header {
            background-color: #2196F3;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-header h1 {
            margin: 0;
            font-size: 24px;
        }
        
        .admin-header a {
            color: #fff;
            text-decoration: none;
        }
        
        .admin-nav {
            background-color: #333;
            color: #fff;
        }
        
        .admin-nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        
        .admin-nav li {
            margin: 0;
        }
        
        .admin-nav a {
            display: block;
            padding: 15px 20px;
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .admin-nav a:hover, .admin-nav a.active {
            background-color: #2196F3;
        }
        
        .admin-content {
            padding: 20px;
            min-height: calc(100vh - 180px);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .page-title {
            color: #333;
            margin-top: 0;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .btn {
            display: inline-block;
            padding: 8px 15px;
            background-color: #2196F3;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: #0b7dda;
        }
        
        .btn-success {
            background-color: #4CAF50;
        }
        
        .btn-success:hover {
            background-color: #45a049;
        }
        
        .btn-danger {
            background-color: #f44336;
        }
        
        .btn-danger:hover {
            background-color: #d32f2f;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .table-container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-top: 20px;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th, .data-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .data-table th {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #333;
        }
        
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            max-width: 600px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .admin-footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 15px 0;
        }
        
        .current-user {
            font-weight: bold;
            color: #2196F3;
        }
        
        .password-hint {
            color: #666;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <header class="admin-header">
        <h1><a href="index.php"><?php echo SITE_NAME; ?> 管理后台</a></h1>
        <div class="user-menu">
            <span>欢迎回来，<?php echo get_current_admin()['username']; ?></span> | 
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> 退出</a>
        </div>
    </header>
    
    <nav class="admin-nav">
        <div class="container">
            <ul>
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> 仪表盘</a></li>
                <li><a href="articles.php"><i class="fas fa-file-alt"></i> 文章管理</a></li>
                <li><a href="categories.php"><i class="fas fa-folder"></i> 分类管理</a></li>
                <li><a href="comments.php"><i class="fas fa-comments"></i> 评论管理</a></li>
                <li><a href="users.php" class="active"><i class="fas fa-users"></i> 用户管理</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="admin-content">
        <div class="container">
            <?php if ($message) : ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($action === 'list') : ?>
                <h2 class="page-title">
                    用户管理
                    <a href="users.php?action=add" class="btn btn-success"><i class="fas fa-plus"></i> 新建用户</a>
                </h2>
                
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>用户名</th>
                                <th>邮箱</th>
                                <th>创建时间</th>
                                <th>最后登录</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($users)) : ?>
                                <?php foreach ($users as $user) : ?>
                                    <tr>
                                        <td><?php echo $user['id']; ?></td>
                                        <td><?php echo htmlspecialspecialchars($user['username']); ?> <?php echo ($user['id'] == $_SESSION['admin_id']) ? '<span class="current-user">(当前用户)</span>' : ''; ?></td>
                                        <td><?php echo htmlspecialspecialchars($user['email']); ?></td>
                                        <td><?php echo format_datetime($user['created_at'], 'Y-m-d'); ?></td>
                                        <td><?php echo $user['last_login'] ? format_datetime($user['last_login'], 'Y-m-d H:i') : '从未登录'; ?></td>
                                        <td class="action-buttons">
                                            <a href="users.php?action=edit&id=<?php echo $user['id']; ?>" class="btn btn-sm"><i class="fas fa-edit"></i> 编辑</a>
                                            <?php if ($user['id'] != $_SESSION['admin_id']) : ?>
                                                <a href="users.php?action=delete&id=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定要删除这个用户吗？');"><i class="fas fa-trash"></i> 删除</a>
                                            <?php else : ?>
                                                <button class="btn btn-sm btn-danger" disabled><i class="fas fa-trash"></i> 删除</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="6" style="text-align: center;">暂无用户</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
            <?php elseif ($action === 'add' || $action === 'edit') : ?>
                <h2 class="page-title">
                    <?php echo $action === 'add' ? '新建用户' : '编辑用户'; ?>
                    <a href="users.php" class="btn"><i class="fas fa-arrow-left"></i> 返回列表</a>
                </h2>
                
                <div class="form-container">
                    <form action="<?php echo $action === 'add' ? 'users.php?action=add' : 'users.php?action=edit&id=' . $user_id; ?>" method="post">
                        <div class="form-group">
                            <label for="username">用户名 <span class="required">*</span></label>
                            <input type="text" id="username" name="username" class="form-control" required value="<?php echo $action === 'edit' ? htmlspecialspecialchars($user['username']) : (isset($_POST['username']) ? htmlspecialspecialchars($_POST['username']) : ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="email">邮箱 <span class="required">*</span></label>
                            <input type="email" id="email" name="email" class="form-control" required value="<?php echo $action === 'edit' ? htmlspecialspecialchars($user['email']) : (isset($_POST['email']) ? htmlspecialspecialchars($_POST['email']) : ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="password">密码 <?php echo $action === 'edit' ? '(留空表示不修改)' : '<span class="required">*</span>'; ?></label>
                            <input type="password" id="password" name="password" class="form-control" <?php echo $action === 'add' ? 'required' : ''; ?>>
                            <?php if ($action === 'edit') : ?>
                                <p class="password-hint">留空表示不修改密码</p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">确认密码 <?php echo $action === 'edit' ? '(留空表示不修改)' : '<span class="required">*</span>'; ?></label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control" <?php echo $action === 'add' ? 'required' : ''; ?>>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> 保存</button>
                            <a href="users.php" class="btn" style="margin-left: 10px;">取消</a>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </main>
    
    <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> 管理后台 - 版权所有</p>
    </footer>
</body>
</html>
